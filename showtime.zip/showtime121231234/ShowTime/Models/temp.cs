﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShowTime.Models
{
    public class temp
    {
        public string ab { get; set; }
        public string bc { get; set; }
    }
}